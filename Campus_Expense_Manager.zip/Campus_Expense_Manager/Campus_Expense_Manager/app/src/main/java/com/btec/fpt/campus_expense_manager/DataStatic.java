package com.btec.fpt.campus_expense_manager;

public class DataStatic {

    public static String email;
    public  static String password;
}
