package com.btec.fpt.campus_expense_manager;

public class BudgetCategoryAdapter {
}
